
package whiteboardtools;

public enum Tool {PENCIL  , ERASER  , BRUSH  ,
                  SQUARE  , OVAL    , LINE   ,
                  POLYGON , AIRBRUSH, PICKER , 
                  BUCKET  , RECTANGLE, FILLER, ROUND_RECT };
