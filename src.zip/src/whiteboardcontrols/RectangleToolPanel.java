/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package whiteboardcontrols;

import whiteboardtools.*;

public class RectangleToolPanel extends RectShapeToolPanel
{
    public RectangleToolPanel(Tool tool, int stroke)
    {
        super(tool, stroke);
    }
}
