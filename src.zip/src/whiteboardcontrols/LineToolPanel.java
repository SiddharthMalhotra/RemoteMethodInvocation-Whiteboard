/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package whiteboardcontrols;

import java.awt.*;

import whiteboardtools.*;

public class LineToolPanel extends DragShapeToolPanel
{
    public LineToolPanel(Tool tool, int stroke)
    {
        super(tool, stroke);
    }
}
