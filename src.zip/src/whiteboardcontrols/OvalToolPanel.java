
package whiteboardcontrols;

import whiteboardtools.*;

public class OvalToolPanel extends RectShapeToolPanel
{
    public OvalToolPanel(Tool tool, int stroke)
    {
        super(tool, stroke);
    }
}
