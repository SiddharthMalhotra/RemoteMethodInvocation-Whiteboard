/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package whiteboardshapetools;

import java.awt.*;

import whiteboardtools.*;

public abstract class ShapeTool extends AbstractTool
{
    public ShapeTool(Color clr, int dim)
    {
        super(clr, dim);
    }
}
